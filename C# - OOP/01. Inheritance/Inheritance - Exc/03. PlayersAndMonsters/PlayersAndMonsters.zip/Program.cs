﻿using System;

namespace PlayersAndMonsters
{
  public  class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
