﻿using System;
using System.Linq;
using Vehicles.Solid;

namespace Vehicles
	{
	public class Program
		{
		static void Main (string[] args)
		{

			string[] carData = Console.ReadLine()
				.Split(" ", StringSplitOptions.RemoveEmptyEntries)
				.ToArray();
			Car car = new Car(double.Parse(carData[1]), double.Parse(carData[2]));

			string[] truckData = Console.ReadLine()
				.Split(" ", StringSplitOptions.RemoveEmptyEntries)
				.ToArray();
			Truck truck = new Truck(double.Parse(truckData[1]), double.Parse(truckData[2]));

			int n = int.Parse(Console.ReadLine());

			for (int i = 0; i < n; i++)
			{
				string[] data = Console.ReadLine()
					.Split(" ", StringSplitOptions.RemoveEmptyEntries)
					.ToArray();
				if (data[0].ToLower() == "drive")
				{
					if (data[1].ToLower() == "car")
					{
						car.Drive(double.Parse(data[2]));
					}
					else if (data[1].ToLower() == "truck")
					{
						truck.Drive(double.Parse(data[2]));
					}
				}
				else if (data[0].ToLower() == "refuel")
				{
					if (data[1].ToLower() == "car")
					{
						car.Refuel(double.Parse(data[2]));
					}
					else if (data[1].ToLower() == "truck")
					{
						truck.Refuel(double.Parse(data[2]));
					}
				}
			}

			Console.WriteLine($"Car: {car.FuelQuantity:f2}");
			Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");

		}
		}
	}
