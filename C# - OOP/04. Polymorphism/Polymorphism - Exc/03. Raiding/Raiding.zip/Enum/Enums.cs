﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Enum
	{
	public enum Enums
		{
			Druid = 0,
			Paladin = 1,
			Rogue = 2,
			Warrior = 3,
		}
	}
