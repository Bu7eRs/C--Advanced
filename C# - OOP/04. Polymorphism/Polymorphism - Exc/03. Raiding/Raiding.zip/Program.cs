﻿using System;
using System.Collections.Generic;
using System.Linq;
using Raiding.Enum;
using Raiding.Solid;

namespace Raiding
	{
		class Program
		{
			static void Main(string[] args)
			{
				List<BaseHero> heroes = new List<BaseHero>();

				int n = int.Parse(Console.ReadLine());

				for (int i = 0; i < n; i++)
				{
					string currHeroName = Console.ReadLine();
					string currHeroRole = Console.ReadLine();
					if (currHeroRole == "Paladin" || currHeroRole == "Warrior" || currHeroRole == "Druid" || currHeroRole == "Rogue")
					{
						if (currHeroRole.ToLower() == "paladin")
						{
							BaseHero currHero = new Paladin(currHeroName);
							heroes.Add(currHero);
						}
						else if (currHeroRole.ToLower() == "warrior")
						{
							BaseHero currHero = new Warrior(currHeroName);
							heroes.Add(currHero);
						}
						else if (currHeroRole.ToLower() == "druid")
						{
							BaseHero currHero = new Druid(currHeroName);
							heroes.Add(currHero);
						}
						else if (currHeroRole.ToLower() == "rogue")
						{
							BaseHero currHero = new Rogue(currHeroName);
							heroes.Add(currHero);
						}
					}
					else
					{
						Console.WriteLine($"Invalid hero!");
					}
				}

				int BossPower = int.Parse(Console.ReadLine());
				int heroesPower = 0;
				foreach (var hero in heroes)
				{
					Console.WriteLine(hero.CastAbility());
					heroesPower += hero.Power;
				}
				StatusCheck(BossPower, heroesPower);
			}

			static void StatusCheck(int bossPower, int heroesPower)
			{
				if (bossPower > heroesPower)
				{
					Console.WriteLine($"Defeat...");
				}
				else
				{
					Console.WriteLine($"Victory!");
				}
			}
		}
	}
